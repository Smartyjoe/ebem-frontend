
  # Premium Minimalist Ecommerce Website

  This is a code bundle for Premium Minimalist Ecommerce Website. The original project is available at https://www.figma.com/design/q1qmC4fCsRamGE360H8w09/Premium-Minimalist-Ecommerce-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  